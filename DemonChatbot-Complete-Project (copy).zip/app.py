
from flask import Flask, render_template, request, session, redirect, url_for
from openai import OpenAI
import os
from dotenv import load_dotenv
import time
from datetime import datetime, timedelta

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    print("ERROR: OPENAI_API_KEY not found in environment variables")
else:
    print(f"API key loaded: {api_key[:10]}...{api_key[-4:]}")
client = OpenAI(api_key=api_key)

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "your-secret-key-here")

# Simple in-memory storage (in production, use a database)
user_usage = {}
user_chat_history = {}  # Store chat sessions by user
MAX_FREE_MESSAGES = 3
RESET_HOURS = 24
MAX_CHAT_SESSIONS = 10  # Limit stored sessions per user

def get_reset_timestamp(user_id):
    """Get the timestamp when user's messages will reset"""
    if user_id not in user_usage:
        return None
    
    first_message_time = user_usage[user_id].get("first_message_time")
    if not first_message_time:
        return None
    
    reset_time = first_message_time + (RESET_HOURS * 60 * 60 * 1000)  # 24 hours in milliseconds
    return reset_time

def has_time_expired(user_id):
    """Check if 24 hours have passed since first message"""
    reset_time = get_reset_timestamp(user_id)
    if not reset_time:
        return False
    
    current_time = int(time.time() * 1000)
    return current_time >= reset_time

def reset_user_usage(user_id):
    """Reset user's message count and timestamp"""
    user_usage[user_id] = {
        "messages_used": 0, 
        "paid": False, 
        "first_message_time": None
    }

def save_chat_session(user_id, messages):
    """Save current chat session to history"""
    if not messages or len(messages) == 0:
        return
    
    if user_id not in user_chat_history:
        user_chat_history[user_id] = []
    
    # Create session with timestamp
    session_data = {
        "timestamp": int(time.time() * 1000),
        "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "messages": messages.copy(),
        "preview": messages[0]["content"][:50] + "..." if len(messages[0]["content"]) > 50 else messages[0]["content"]
    }
    
    # Add to beginning of history
    user_chat_history[user_id].insert(0, session_data)
    
    # Keep only recent sessions
    if len(user_chat_history[user_id]) > MAX_CHAT_SESSIONS:
        user_chat_history[user_id] = user_chat_history[user_id][:MAX_CHAT_SESSIONS]

def get_user_chat_history(user_id):
    """Get user's chat history"""
    return user_chat_history.get(user_id, [])

@app.route("/", methods=["GET", "POST"])
def chat():
    # Get user IP as identifier (in production, use proper user authentication)
    user_id = request.remote_addr
    
    if user_id not in user_usage:
        user_usage[user_id] = {"messages_used": 0, "paid": False, "first_message_time": None}
    
    # Check if 24 hours have passed and reset if so
    if has_time_expired(user_id):
        reset_user_usage(user_id)
    
    messages = session.get('messages', [])
    chat_history = get_user_chat_history(user_id)
    
    if request.method == "POST":
        # Check if user has exceeded free limit and hasn't paid
        if (user_usage[user_id]["messages_used"] >= MAX_FREE_MESSAGES and 
            not user_usage[user_id]["paid"]):
            
            reset_time = get_reset_timestamp(user_id)
            current_time = int(time.time() * 1000)
            time_remaining = "24h 0m 0s"
            
            if reset_time:
                time_left = reset_time - current_time
                if time_left > 0:
                    hours = time_left // (1000 * 60 * 60)
                    minutes = (time_left % (1000 * 60 * 60)) // (1000 * 60)
                    seconds = (time_left % (1000 * 60)) // 1000
                    time_remaining = f"{hours}h {minutes}m {seconds}s"
            
            return render_template("Click here to download it.html", 
                                 used=user_usage[user_id]["messages_used"], 
                                 max_free=MAX_FREE_MESSAGES,
                                 time_remaining=time_remaining,
                                 reset_timestamp=reset_time or current_time + (24 * 60 * 60 * 1000))
        
        user_input = request.form["message"]
        messages.append({"role": "user", "content": user_input})
        
        try:
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are Kedaeshure, a terrifying demon who speaks cryptically..."},
                    *messages
                ]
            )
            reply = response.choices[0].message.content
            messages.append({"role": "assistant", "content": reply})
            
            # Only increment usage counter on successful API call
            user_usage[user_id]["messages_used"] += 1
            if user_usage[user_id]["first_message_time"] is None:
                user_usage[user_id]["first_message_time"] = int(time.time() * 1000)
            session['messages'] = messages
            
        except Exception as e:
            error_message = "The demon is temporarily unavailable. Please try again later."
            if "quota" in str(e).lower() or "rate_limit" in str(e).lower():
                error_message = "Too many summons! The demon needs rest. Try again later."
            elif "insufficient_quota" in str(e).lower():
                error_message = "The demon's power is depleted. The summoner must replenish the magical essence (API credits)."
            
            # Don't increment message count for API failures
            messages.append({"role": "system", "content": f"Error: {error_message}"})
            session['messages'] = messages
            print(f"API Error: {str(e)}")  # For debugging
        
        # Set session flag for template
        session['paid_user'] = user_usage[user_id]["paid"]
        return render_template("chat.html", messages=messages, chat_history=chat_history)
    
    # Set session flag for template
    session['paid_user'] = user_usage[user_id]["paid"]
    return render_template("chat.html", messages=messages, chat_history=chat_history)

@app.route("/reset")
def reset_limit():
    # Simple reset for testing (in production, verify payment)
    user_id = request.remote_addr
    if user_id in user_usage:
        user_usage[user_id]["paid"] = True
    return redirect(url_for('chat'))

@app.route("/payment-success")
def payment_success():
    # This route would be called after successful Gumroad payment
    # In production, verify the payment with Gumroad's API
    user_id = request.remote_addr
    if user_id in user_usage:
        user_usage[user_id]["paid"] = True
        # Clear their session to start fresh
        session.pop('messages', None)
    
    return render_template("payment_success.html")

@app.route("/clear")
def clear_chat():
    # Save current session before clearing
    user_id = request.remote_addr
    messages = session.get('messages', [])
    if len(messages) > 0:
        save_chat_session(user_id, messages)
    
    session.pop('messages', None)
    return redirect(url_for('chat'))

@app.route("/load-chat/<int:session_index>")
def load_chat(session_index):
    """Load a previous chat session"""
    user_id = request.remote_addr
    chat_history = get_user_chat_history(user_id)
    
    if 0 <= session_index < len(chat_history):
        # Save current session first if it has messages
        current_messages = session.get('messages', [])
        if len(current_messages) > 0:
            save_chat_session(user_id, current_messages)
        
        # Load selected session
        session['messages'] = chat_history[session_index]['messages']
    
    return redirect(url_for('chat'))

@app.route("/test-voice")
def test_voice():
    """Test voice feature for premium users"""
    user_id = request.remote_addr
    if user_id in user_usage and user_usage[user_id]["paid"]:
        return {"status": "success", "message": "The demon's voice awakens... Prepare yourself, mortal."}
    return {"status": "error", "message": "Voice features require premium access"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
