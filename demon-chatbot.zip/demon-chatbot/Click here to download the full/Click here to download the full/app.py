from client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))flask import Flask, render_template, request
import openai
import os
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def chat():
    messages = []
    if request.method == "POST":
        user_input = request.form["message"]
        messages.append({"role": "user", "content": user_input})

        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are Kedaeshure, a terrifying demon who speaks cryptically..."},
                *messages
            ]
        )
        reply = response["choices"][0]["message"]["content"]
        messages.append({"role": "assistant", "content": reply})
        return render_template("chat.html", messages=messages)

    return render_template("chat.html", messages=[])

if __name__ == "__main__":
    app.run(debug=True)
